/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Syne', 'sans-serif'],
        body:    ['DM Sans', 'sans-serif'],
        mono:    ['DM Mono', 'monospace'],
      },
      colors: {
        canvas:  '#F5F2ED',
        surface: '#FFFFFF',
        ink:     '#0F0F0F',
        muted:   '#6B6B6B',
        subtle:  '#B0ADA8',
        border:  '#E2DED8',
        accent:  '#0A5C3C',   /* deep forest green — primary action */
        'accent-light': '#E8F5EE',
        gold:    '#C8940A',
        'gold-light': '#FDF6E3',
        danger:  '#C0392B',
        'danger-light': '#FDECEA',
        success: '#1A7F5A',
        'success-light': '#E8F5EE',
      },
      borderRadius: {
        DEFAULT: '8px',
        lg: '12px',
        xl: '16px',
        '2xl': '24px',
      },
      boxShadow: {
        card:  '0 1px 3px rgba(0,0,0,0.06), 0 4px 16px rgba(0,0,0,0.04)',
        float: '0 8px 32px rgba(0,0,0,0.10)',
        inner: 'inset 0 1px 2px rgba(0,0,0,0.06)',
      },
    },
  },
  plugins: [],
};
