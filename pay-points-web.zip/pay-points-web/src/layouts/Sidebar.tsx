import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import clsx from 'clsx';
import { useAuthStore } from '@/store/authStore';
import { useWallet, usePointsAccount } from '@/hooks/usePayPoints';
import { Amount, TierBadge } from '@/components/ui';
import { Tier } from '@/utils/helpers';

const NAV = [
  { to: '/',            label: 'Overview',     icon: NavIcon.Home },
  { to: '/pay',         label: 'Pay',          icon: NavIcon.Pay },
  { to: '/rewards',     label: 'Rewards',      icon: NavIcon.Rewards },
  { to: '/transactions',label: 'Transactions', icon: NavIcon.Txns },
  { to: '/profile',     label: 'Profile',      icon: NavIcon.Profile },
];

function NavIcon({ name }: { name: string }) {
  const icons: Record<string, React.ReactNode> = {
    Home:    <path d="M3 9.5L12 3l9 6.5V20a1 1 0 0 1-1 1H14v-5h-4v5H4a1 1 0 0 1-1-1V9.5z" />,
    Pay:     <><path d="M12 5v14M5 12h14" /></>,
    Rewards: <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />,
    Txns:    <><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2" /><rect x="9" y="3" width="6" height="4" rx="1" /></>,
    Profile: <><circle cx="12" cy="8" r="4" /><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" /></>,
    Logout:  <><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" /></>,
  };
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
      {icons[name]}
    </svg>
  );
}

export default function Sidebar() {
  const logout   = useAuthStore((s) => s.logout);
  const navigate = useNavigate();
  const { data: wallet }  = useWallet();
  const { data: account } = usePointsAccount();

  return (
    <aside className="w-64 min-h-screen bg-surface border-r border-border flex flex-col">
      {/* Logo */}
      <div className="px-6 py-5 border-b border-border">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center text-white text-sm font-display font-bold">P</div>
          <span className="font-display text-lg font-bold text-ink tracking-tight">PayPoints</span>
        </div>
      </div>

      {/* Wallet card */}
      {wallet && (
        <div className="mx-4 mt-4 p-4 rounded-xl bg-ink text-white">
          <p className="font-body text-[10px] uppercase tracking-widest opacity-50 mb-1">Balance</p>
          <Amount amount={wallet.balance} currency={wallet.currency} size="lg" />
          <div className="mt-3 flex items-center gap-2">
            <span className="font-mono text-xs opacity-50">{account?.totalPoints?.toLocaleString() ?? '—'} pts</span>
            {account?.tier && (
              <span className="font-mono text-[10px] opacity-60">· {account.tier}</span>
            )}
          </div>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5">
        {NAV.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              clsx(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-body transition-colors duration-150',
                isActive
                  ? 'bg-accent/8 text-accent font-medium'
                  : 'text-muted hover:bg-canvas hover:text-ink'
              )
            }
          >
            <Icon name={label === 'Overview' ? 'Home' : label === 'Transactions' ? 'Txns' : label} />
            {label}
          </NavLink>
        ))}
      </nav>

      {/* Logout */}
      <div className="px-3 pb-4 border-t border-border pt-3">
        <button
          onClick={() => { logout(); navigate('/login'); }}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-body text-muted hover:bg-canvas hover:text-danger transition-colors duration-150"
        >
          <NavIcon name="Logout" />
          Sign out
        </button>
      </div>
    </aside>
  );
}
