import { format, isToday, isYesterday } from 'date-fns';
import { nanoid } from 'nanoid';

export const fmt = {
  currency: (n: number, currency = 'ZAR') =>
    new Intl.NumberFormat('en-ZA', { style: 'currency', currency, minimumFractionDigits: 2 }).format(n),

  points: (n: number) => n.toLocaleString('en-ZA') + ' pts',

  date: (iso: string) => {
    const d = new Date(iso);
    if (isToday(d))     return `Today, ${format(d, 'HH:mm')}`;
    if (isYesterday(d)) return `Yesterday, ${format(d, 'HH:mm')}`;
    return format(d, 'dd MMM yyyy, HH:mm');
  },

  shortDate: (iso: string) => format(new Date(iso), 'dd MMM'),

  ref: (prefix = 'PAY') => `${prefix}-${nanoid(8).toUpperCase()}`,
};

export type Tier = 'BRONZE' | 'SILVER' | 'GOLD' | 'PLATINUM';

export const TIER_ORDER: Tier[] = ['BRONZE', 'SILVER', 'GOLD', 'PLATINUM'];

export const TIER_RANGES: Record<Tier, [number, number]> = {
  BRONZE:   [0,     1_000],
  SILVER:   [1_000, 5_000],
  GOLD:     [5_000, 15_000],
  PLATINUM: [15_000, 15_000],
};

export function tierProgress(points: number, tier: Tier): number {
  if (tier === 'PLATINUM') return 100;
  const [min, max] = TIER_RANGES[tier];
  return Math.min(Math.max(Math.round(((points - min) / (max - min)) * 100), 0), 100);
}

export const TIER_COLORS: Record<Tier, string> = {
  BRONZE:   '#CD7F32',
  SILVER:   '#8A9BB0',
  GOLD:     '#C8940A',
  PLATINUM: '#6B8FAF',
};

export const TX_ICONS: Record<string, string> = {
  CREDIT: '↙', DEBIT: '↗', TRANSFER: '⇄',
};

export const TX_STATUS_CLASS: Record<string, string> = {
  COMPLETED: 'badge-success',
  PENDING:   'badge-neutral',
  FAILED:    'badge-danger',
  REVERSED:  'badge-neutral',
};

export const clamp = (n: number, min: number, max: number) => Math.min(Math.max(n, min), max);
