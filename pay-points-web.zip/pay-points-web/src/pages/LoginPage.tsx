import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';
import { Button, Input } from '@/components/ui';

export default function LoginPage() {
  const [mode, setMode]         = useState<'login' | 'register'>('login');
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone]       = useState('');
  const [localError, setLocalError] = useState('');

  const { login, register, isLoading, isAuthenticated, error } = useAuthStore();
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) navigate('/', { replace: true });
  }, [isAuthenticated, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError('');
    try {
      if (mode === 'login') {
        await login(email.trim(), password);
      } else {
        if (!fullName.trim()) { setLocalError('Full name is required'); return; }
        await register(email.trim(), password, fullName.trim(), phone || undefined);
      }
    } catch {
      // error set in store
    }
  };

  const displayError = localError || error;

  return (
    <div className="min-h-screen bg-canvas flex">
      {/* Left panel – branding */}
      <div className="hidden lg:flex w-[46%] bg-ink flex-col justify-between p-12">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-accent flex items-center justify-center text-white font-display font-bold text-base">P</div>
          <span className="font-display text-xl font-bold text-white tracking-tight">PayPoints</span>
        </div>

        <div className="space-y-6">
          <h2 className="font-display text-5xl font-bold text-white leading-tight tracking-tight">
            Payments that<br />
            <span className="text-accent">reward you</span>
          </h2>
          <p className="font-body text-base text-white/50 leading-relaxed max-w-sm">
            Send money, earn points on every transaction, and unlock exclusive rewards as you level up your tier.
          </p>
        </div>

        <div className="flex items-center gap-6 font-mono text-xs text-white/30">
          <span>256-bit encryption</span>
          <span>·</span>
          <span>Instant transfers</span>
          <span>·</span>
          <span>AI fraud detection</span>
        </div>
      </div>

      {/* Right panel – form */}
      <div className="flex-1 flex items-center justify-center px-8">
        <div className="w-full max-w-sm">
          {/* Mobile logo */}
          <div className="flex items-center gap-2.5 mb-10 lg:hidden">
            <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center text-white font-display font-bold text-sm">P</div>
            <span className="font-display text-lg font-bold text-ink">PayPoints</span>
          </div>

          <h1 className="font-display text-2xl font-bold text-ink mb-1">
            {mode === 'login' ? 'Welcome back' : 'Create account'}
          </h1>
          <p className="font-body text-sm text-muted mb-8">
            {mode === 'login'
              ? 'Sign in to your PayPoints account'
              : 'Join PayPoints and start earning rewards'}
          </p>

          {/* Mode toggle */}
          <div className="flex bg-canvas border border-border rounded-lg p-1 mb-6">
            {(['login', 'register'] as const).map((m) => (
              <button
                key={m}
                onClick={() => { setMode(m); setLocalError(''); }}
                className={`flex-1 py-2 rounded text-sm font-body transition-all duration-150 ${
                  mode === m
                    ? 'bg-surface text-ink font-medium shadow-sm border border-border'
                    : 'text-muted hover:text-ink'
                }`}
              >
                {m === 'login' ? 'Sign in' : 'Register'}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <Input
                label="Full name"
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Jane Smith"
                autoComplete="name"
              />
            )}

            <Input
              label="Email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              autoComplete="email"
            />

            {mode === 'register' && (
              <Input
                label="Phone (optional)"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+27 80 000 0000"
              />
            )}

            <Input
              label="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
            />

            {displayError && (
              <div className="p-3 rounded-lg bg-danger-light border border-danger/20 text-sm font-body text-danger">
                {displayError}
              </div>
            )}

            <Button
              type="submit"
              loading={isLoading}
              disabled={!email || !password}
              className="w-full mt-2"
              size="lg"
            >
              {mode === 'login' ? 'Sign in' : 'Create account'}
            </Button>

            {mode === 'login' && (
              <button type="button" className="w-full text-center font-body text-sm text-accent hover:underline mt-1">
                Forgot password?
              </button>
            )}
          </form>

          <p className="font-body text-xs text-muted text-center mt-8">
            By continuing you agree to our{' '}
            <a href="#" className="text-accent hover:underline">Terms of Service</a>
            {' '}and{' '}
            <a href="#" className="text-accent hover:underline">Privacy Policy</a>
          </p>
        </div>
      </div>
    </div>
  );
}
