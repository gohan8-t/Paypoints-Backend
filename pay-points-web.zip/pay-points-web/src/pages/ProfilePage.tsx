import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePointsAccount } from '@/hooks/usePayPoints';
import { useAuthStore } from '@/store/authStore';
import { Card, TierBadge, ProgressBar, Divider, Button } from '@/components/ui';
import { TIER_COLORS, TIER_RANGES, tierProgress, Tier } from '@/utils/helpers';

const MILESTONES: { tier: Tier; label: string; pts: number }[] = [
  { tier: 'BRONZE',   label: 'Bronze',   pts: 0 },
  { tier: 'SILVER',   label: 'Silver',   pts: 1_000 },
  { tier: 'GOLD',     label: 'Gold',     pts: 5_000 },
  { tier: 'PLATINUM', label: 'Platinum', pts: 15_000 },
];
const TIER_ORDER: Tier[] = ['BRONZE', 'SILVER', 'GOLD', 'PLATINUM'];

interface SettingRowProps {
  icon: string; label: string; sub?: string;
  onClick?: () => void; danger?: boolean;
  trailing?: React.ReactNode;
}
function SettingRow({ icon, label, sub, onClick, danger, trailing }: SettingRowProps) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3.5 py-3 px-1 rounded-lg text-left transition-colors group ${
        onClick ? 'hover:bg-canvas cursor-pointer' : 'cursor-default'
      }`}
    >
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-base flex-shrink-0 ${
        danger ? 'bg-danger-light' : 'bg-canvas'
      }`}>
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className={`font-body text-sm ${danger ? 'text-danger' : 'text-ink'}`}>{label}</p>
        {sub && <p className="font-body text-xs text-muted">{sub}</p>}
      </div>
      {trailing ?? (onClick && !danger && (
        <svg className="text-subtle group-hover:text-muted transition-colors" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="m9 18 6-6-6-6" />
        </svg>
      ))}
    </button>
  );
}

export default function ProfilePage() {
  const logout   = useAuthStore((s) => s.logout);
  const navigate = useNavigate();
  const { data: account } = usePointsAccount();
  const [notifs, setNotifs]   = useState(true);
  const [biometric, setBiometric] = useState(true);

  const tier    = (account?.tier ?? 'BRONZE') as Tier;
  const color   = TIER_COLORS[tier];
  const progress = account ? tierProgress(account.totalPoints, tier) : 0;
  const tierIdx  = TIER_ORDER.indexOf(tier);

  const handleLogout = () => {
    if (confirm('Sign out of PayPoints?')) {
      logout();
      navigate('/login');
    }
  };

  return (
    <div className="page-enter space-y-8 max-w-xl">
      <div>
        <h1 className="font-display text-2xl text-ink">Profile</h1>
        <p className="font-body text-sm text-muted mt-0.5">Account settings and preferences</p>
      </div>

      {/* Tier card */}
      <Card className="p-6">
        <div className="flex items-center gap-5 mb-6">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-display font-bold border-2 flex-shrink-0"
            style={{ borderColor: color, color, backgroundColor: color + '12' }}
          >
            {tier[0]}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="font-display text-xl font-bold text-ink">{tier}</span>
              <TierBadge tier={tier} size="sm" />
            </div>
            <p className="font-mono text-sm" style={{ color }}>
              {account?.totalPoints?.toLocaleString() ?? 0} points
            </p>
          </div>
        </div>

        {/* Progress */}
        <div className="mb-3">
          <div className="flex justify-between font-mono text-xs text-muted mb-1.5">
            <span>{progress}%</span>
            {tier !== 'PLATINUM' && <span>Next: {MILESTONES[tierIdx + 1]?.label}</span>}
          </div>
          <ProgressBar value={progress} color={color} />
        </div>

        {/* Milestones */}
        <div className="flex items-center mt-5">
          {MILESTONES.map((m, i) => {
            const reached = tierIdx >= i;
            const mColor  = TIER_COLORS[m.tier];
            return (
              <React.Fragment key={m.tier}>
                <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
                  <div
                    className="w-4 h-4 rounded-full border-2 transition-colors"
                    style={{
                      borderColor: mColor,
                      backgroundColor: reached ? mColor : 'transparent',
                    }}
                  />
                  <span className="font-mono text-[9px]" style={{ color: reached ? mColor : '#B0ADA8' }}>
                    {m.label}
                  </span>
                  <span className="font-mono text-[9px] text-subtle">
                    {m.pts === 0 ? 'Start' : `${(m.pts / 1000).toFixed(0)}k`}
                  </span>
                </div>
                {i < MILESTONES.length - 1 && (
                  <div
                    className="flex-1 h-px mx-1 mb-6 transition-colors"
                    style={{ backgroundColor: tierIdx > i ? color + '60' : '#E2DED8' }}
                  />
                )}
              </React.Fragment>
            );
          })}
        </div>
      </Card>

      {/* Account section */}
      <Card className="p-5 space-y-1">
        <p className="font-body text-[10px] text-muted uppercase tracking-widest px-1 mb-2">Account</p>
        <SettingRow icon="👤" label="Personal info"    sub="Name, phone, email"  onClick={() => {}} />
        <SettingRow icon="🔒" label="Security"         sub="PIN, password, 2FA"  onClick={() => {}} />
        <SettingRow icon="🪪" label="KYC verification" sub="Identity · Pending"  onClick={() => {}} />
        <SettingRow icon="💳" label="Linked accounts"  sub="Banks, cards"        onClick={() => {}} />
      </Card>

      {/* Preferences section */}
      <Card className="p-5 space-y-1">
        <p className="font-body text-[10px] text-muted uppercase tracking-widest px-1 mb-2">Preferences</p>
        <SettingRow
          icon="🔔" label="Push notifications"
          trailing={
            <button
              onClick={() => setNotifs((v) => !v)}
              className={`w-10 h-5.5 rounded-full transition-colors relative flex-shrink-0 ${notifs ? 'bg-accent' : 'bg-border'}`}
              style={{ height: 22, width: 40 }}
            >
              <span
                className="absolute top-0.5 left-0.5 w-4.5 h-4.5 bg-white rounded-full shadow transition-transform"
                style={{ width: 18, height: 18, transform: notifs ? 'translateX(18px)' : 'translateX(0)' }}
              />
            </button>
          }
        />
        <SettingRow
          icon="🌍" label="Currency" sub="ZAR – South African Rand" onClick={() => {}} />
        <SettingRow
          icon="🎨" label="Theme" sub="System default" onClick={() => {}} />
      </Card>

      {/* Support section */}
      <Card className="p-5 space-y-1">
        <p className="font-body text-[10px] text-muted uppercase tracking-widest px-1 mb-2">Support</p>
        <SettingRow icon="❓" label="Help centre"      onClick={() => {}} />
        <SettingRow icon="📞" label="Contact support"  onClick={() => {}} />
        <SettingRow icon="📄" label="Terms & Privacy"  onClick={() => {}} />
        <SettingRow icon="ℹ"  label="App version"     sub="v1.0.0" />
      </Card>

      {/* Logout */}
      <Card className="p-5">
        <SettingRow icon="🚪" label="Sign out" onClick={handleLogout} danger />
      </Card>
    </div>
  );
}
