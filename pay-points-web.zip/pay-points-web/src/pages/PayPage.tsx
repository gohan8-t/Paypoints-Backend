import React, { useState } from 'react';
import { Card, Button, Input, Amount } from '@/components/ui';
import { useDebitWallet, useWallet } from '@/hooks/usePayPoints';
import { fmt } from '@/utils/helpers';

const QUICK_AMOUNTS = [50, 100, 200, 500, 1000];

const RECENT_CONTACTS = [
  { id: '1', name: 'Zanele M.',  initial: 'Z', color: '#7C3AED' },
  { id: '2', name: 'Sipho K.',   initial: 'S', color: '#0891B2' },
  { id: '3', name: 'Ayanda T.',  initial: 'A', color: '#059669' },
  { id: '4', name: 'Lerato N.',  initial: 'L', color: '#DC2626' },
  { id: '5', name: 'Thabo M.',   initial: 'T', color: '#9333EA' },
];

export default function PayPage() {
  const [amount, setAmount]       = useState('');
  const [recipient, setRecipient] = useState('');
  const [note, setNote]           = useState('');
  const [success, setSuccess]     = useState<string | null>(null);
  const [error, setError]         = useState<string | null>(null);

  const { data: wallet } = useWallet();
  const { mutate: debit, isPending } = useDebitWallet();

  const numAmount = parseFloat(amount);
  const canPay = numAmount > 0 && recipient.trim().length > 0 && !isPending;
  const insufficient = wallet && numAmount > wallet.balance;

  const handlePay = () => {
    setError(null);
    setSuccess(null);
    debit(
      { amount: numAmount, ref: fmt.ref('PAY'), desc: note || `Payment to ${recipient}` },
      {
        onSuccess: () => {
          setSuccess(`ZAR ${numAmount.toFixed(2)} sent to ${recipient}`);
          setAmount(''); setRecipient(''); setNote('');
        },
        onError: (e: any) => setError(e?.response?.data?.message ?? 'Payment failed'),
      }
    );
  };

  return (
    <div className="page-enter space-y-6 max-w-lg">
      <div>
        <h1 className="font-display text-2xl text-ink">Send payment</h1>
        {wallet && (
          <p className="font-body text-sm text-muted mt-0.5">
            Available: <span className="font-mono text-ink">{fmt.currency(wallet.balance)}</span>
          </p>
        )}
      </div>

      {/* Amount */}
      <Card className="p-6 space-y-5">
        <div>
          <p className="font-body text-xs text-muted uppercase tracking-widest mb-3">Amount</p>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 font-mono text-2xl text-muted font-medium">R</span>
            <input
              type="number"
              min="0.01"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full pl-9 pr-4 py-4 font-mono text-4xl font-medium text-ink bg-canvas rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent/60 transition-colors placeholder-border"
            />
          </div>
          {insufficient && (
            <p className="text-xs text-danger font-body mt-1.5">Insufficient balance</p>
          )}
        </div>

        {/* Quick amounts */}
        <div className="flex gap-2 flex-wrap">
          {QUICK_AMOUNTS.map((q) => (
            <button
              key={q}
              onClick={() => setAmount(q.toString())}
              className="px-3 py-1.5 rounded-lg border border-border bg-canvas font-mono text-xs text-muted hover:border-accent/40 hover:text-accent transition-colors"
            >
              R{q}
            </button>
          ))}
        </div>
      </Card>

      {/* Recipient */}
      <Card className="p-6 space-y-4">
        <p className="font-body text-xs text-muted uppercase tracking-widest">To</p>

        {/* Quick contacts */}
        <div className="flex gap-3 overflow-x-auto pb-1">
          {RECENT_CONTACTS.map((c) => (
            <button
              key={c.id}
              onClick={() => setRecipient(c.name)}
              className={`flex flex-col items-center gap-1.5 group flex-shrink-0 ${recipient === c.name ? 'opacity-100' : 'opacity-60 hover:opacity-100'} transition-opacity`}
            >
              <div
                className="w-11 h-11 rounded-full flex items-center justify-center text-white text-sm font-display font-semibold border-2 transition-all"
                style={{
                  backgroundColor: c.color + '20',
                  color: c.color,
                  borderColor: recipient === c.name ? c.color : 'transparent',
                }}
              >
                {c.initial}
              </div>
              <span className="font-body text-[10px] text-muted">{c.name.split(' ')[0]}</span>
            </button>
          ))}
        </div>

        <Input
          label="Phone or email"
          type="text"
          value={recipient}
          onChange={(e) => setRecipient(e.target.value)}
          placeholder="recipient@example.com"
        />

        <Input
          label="Note (optional)"
          type="text"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="What's this for?"
          maxLength={80}
        />
      </Card>

      {/* Feedback */}
      {success && (
        <div className="p-4 rounded-xl bg-success-light border border-success/20 text-sm font-body text-success">
          ✓ {success}
        </div>
      )}
      {error && (
        <div className="p-4 rounded-xl bg-danger-light border border-danger/20 text-sm font-body text-danger">
          {error}
        </div>
      )}

      {/* Summary + CTA */}
      {numAmount > 0 && recipient && (
        <div className="p-4 rounded-xl bg-canvas border border-border flex items-center justify-between">
          <div>
            <p className="font-body text-xs text-muted">Sending to {recipient}</p>
            <Amount amount={numAmount} size="md" />
          </div>
          <Button
            onClick={handlePay}
            loading={isPending}
            disabled={!canPay || !!insufficient}
            size="lg"
          >
            Send payment
          </Button>
        </div>
      )}
    </div>
  );
}
