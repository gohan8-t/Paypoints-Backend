import React, { useState } from 'react';
import { usePointsAccount, useRewards, useRedeemReward } from '@/hooks/usePayPoints';
import { Card, TierBadge, ProgressBar, Button, Skeleton, EmptyState, Badge } from '@/components/ui';
import { TIER_COLORS, TIER_RANGES, tierProgress, Tier, fmt } from '@/utils/helpers';

const CATEGORIES = ['All', 'AIRTIME', 'FOOD', 'CASHBACK', 'ENTERTAINMENT', 'TRANSPORT'];
const CAT_ICONS: Record<string, string> = {
  All: '✦', AIRTIME: '📶', FOOD: '☕', CASHBACK: '💰', ENTERTAINMENT: '🎬', TRANSPORT: '🚗',
};
const CAT_COLORS: Record<string, string> = {
  AIRTIME: '#0891B2', FOOD: '#C2640A', CASHBACK: '#059669',
  ENTERTAINMENT: '#7C3AED', TRANSPORT: '#2563EB',
};

function TierBanner({ totalPoints, tier }: { totalPoints: number; tier: Tier }) {
  const color    = TIER_COLORS[tier];
  const progress = tierProgress(totalPoints, tier);
  const [, max]  = TIER_RANGES[tier];
  const NEXT_TIER: Record<Tier, string> = { BRONZE: 'Silver', SILVER: 'Gold', GOLD: 'Platinum', PLATINUM: '' };
  const toNext   = tier !== 'PLATINUM' ? max - totalPoints : 0;

  const tierBg: Record<Tier, string> = {
    BRONZE:   'from-amber-50  to-orange-50',
    SILVER:   'from-slate-50  to-blue-50',
    GOLD:     'from-yellow-50 to-amber-50',
    PLATINUM: 'from-blue-50   to-indigo-50',
  };

  return (
    <div className={`rounded-2xl bg-gradient-to-br ${tierBg[tier]} border border-border p-6`}>
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="font-body text-xs text-muted uppercase tracking-widest mb-1">Your status</p>
          <div className="flex items-center gap-3">
            <span className="font-display text-3xl font-bold" style={{ color }}>{tier}</span>
            <TierBadge tier={tier} />
          </div>
        </div>
        <div className="text-right">
          <p className="font-body text-xs text-muted uppercase tracking-widest mb-1">Points</p>
          <span className="font-mono text-2xl font-medium" style={{ color }}>
            {totalPoints.toLocaleString()}
          </span>
        </div>
      </div>
      <ProgressBar value={progress} color={color} className="mb-2" />
      <div className="flex justify-between font-mono text-xs text-muted">
        <span>{progress}% through {tier}</span>
        {toNext > 0
          ? <span>{toNext.toLocaleString()} pts to {NEXT_TIER[tier]}</span>
          : <span>Maximum tier ✦</span>
        }
      </div>
    </div>
  );
}

function RewardCard({
  reward, userPoints, onRedeem, loading,
}: {
  reward: any; userPoints: number; onRedeem: (id: string) => void; loading: boolean;
}) {
  const canAfford = userPoints >= reward.costPoints;
  const accent    = CAT_COLORS[reward.category] ?? '#0A5C3C';
  const outOfStock = reward.stock === 0;

  return (
    <Card className={`p-5 flex flex-col gap-4 transition-opacity ${(!canAfford || outOfStock) ? 'opacity-60' : ''}`}>
      <div className="flex items-start gap-3">
        <div
          className="w-11 h-11 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
          style={{ backgroundColor: accent + '15' }}
        >
          {CAT_ICONS[reward.category] ?? '🎁'}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-body text-sm font-medium text-ink leading-tight">{reward.name}</p>
          <p className="font-body text-xs text-muted mt-0.5 leading-relaxed line-clamp-2">{reward.description}</p>
        </div>
      </div>

      <div className="flex items-center justify-between pt-1 border-t border-border">
        <div>
          <span
            className="font-mono text-sm font-medium"
            style={{ color: canAfford ? accent : '#B0ADA8' }}
          >
            ◆ {reward.costPoints.toLocaleString()} pts
          </span>
          {reward.stock > 0 && reward.stock <= 20 && (
            <span className="font-mono text-[10px] text-muted ml-2">{reward.stock} left</span>
          )}
          {outOfStock && (
            <span className="font-mono text-[10px] text-danger ml-2">Out of stock</span>
          )}
        </div>
        <Button
          variant={canAfford && !outOfStock ? 'primary' : 'secondary'}
          size="sm"
          disabled={!canAfford || outOfStock || loading}
          loading={loading}
          onClick={() => onRedeem(reward.id)}
        >
          {canAfford ? 'Redeem' : 'Need pts'}
        </Button>
      </div>
    </Card>
  );
}

export default function RewardsPage() {
  const [category, setCategory] = useState<string | undefined>(undefined);
  const [redeemingId, setRedeemingId] = useState<string | null>(null);
  const [flash, setFlash] = useState<string | null>(null);

  const { data: account, isLoading: acctLoading } = usePointsAccount();
  const { data: rewards, isLoading: rewardsLoading } = useRewards(category);
  const { mutate: redeem } = useRedeemReward();

  const handleRedeem = (id: string) => {
    const r = rewards?.find((x) => x.id === id);
    if (!r) return;
    if (!confirm(`Redeem "${r.name}" for ${r.costPoints.toLocaleString()} points?`)) return;
    setRedeemingId(id);
    redeem(id, {
      onSuccess: () => { setFlash(`"${r.name}" redeemed successfully!`); setTimeout(() => setFlash(null), 4000); },
      onError:   (e: any) => { setFlash('Error: ' + (e?.response?.data?.message ?? 'Redemption failed')); },
      onSettled: () => setRedeemingId(null),
    });
  };

  const tier = (account?.tier ?? 'BRONZE') as Tier;

  return (
    <div className="page-enter space-y-8">
      <div>
        <h1 className="font-display text-2xl text-ink">Rewards</h1>
        <p className="font-body text-sm text-muted mt-0.5">Redeem your points for great rewards</p>
      </div>

      {/* Tier banner */}
      {acctLoading
        ? <Skeleton className="h-36 rounded-2xl" />
        : account && <TierBanner totalPoints={account.totalPoints} tier={tier} />
      }

      {flash && (
        <div className={`p-3.5 rounded-xl text-sm font-body border ${
          flash.startsWith('Error')
            ? 'bg-danger-light border-danger/20 text-danger'
            : 'bg-success-light border-success/20 text-success'
        }`}>
          {flash.startsWith('Error') ? flash : `✓ ${flash}`}
        </div>
      )}

      {/* Category filter */}
      <div className="flex gap-2 flex-wrap">
        {CATEGORIES.map((cat) => {
          const active = (cat === 'All' ? undefined : cat) === category;
          return (
            <button
              key={cat}
              onClick={() => setCategory(cat === 'All' ? undefined : cat)}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-body border transition-all duration-150 ${
                active
                  ? 'bg-ink text-white border-ink'
                  : 'bg-surface text-muted border-border hover:border-ink/30 hover:text-ink'
              }`}
            >
              <span>{CAT_ICONS[cat]}</span>
              {cat}
            </button>
          );
        })}
      </div>

      {/* Rewards grid */}
      {rewardsLoading ? (
        <div className="grid grid-cols-2 gap-4">
          {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-40 rounded-xl" />)}
        </div>
      ) : !rewards?.length ? (
        <EmptyState icon="🎁" title="No rewards available" description="Check back soon for new rewards in this category." />
      ) : (
        <div className="grid grid-cols-2 gap-4">
          {rewards.map((r) => (
            <RewardCard
              key={r.id}
              reward={r}
              userPoints={account?.totalPoints ?? 0}
              onRedeem={handleRedeem}
              loading={redeemingId === r.id}
            />
          ))}
        </div>
      )}
    </div>
  );
}
