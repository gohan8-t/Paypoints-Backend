import React from 'react';
import { Link } from 'react-router-dom';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid,
} from 'recharts';
import { useWallet, usePointsAccount, useTransactions } from '@/hooks/usePayPoints';
import { Card, Amount, TierBadge, Skeleton, Badge, ProgressBar } from '@/components/ui';
import { fmt, TIER_COLORS, TIER_RANGES, tierProgress, Tier, TX_ICONS, TX_STATUS_CLASS } from '@/utils/helpers';
import { format, subDays } from 'date-fns';

// Build mock sparkline from transactions
function buildSparkline(txs: any[]) {
  const days: Record<string, number> = {};
  for (let i = 6; i >= 0; i--) {
    days[format(subDays(new Date(), i), 'MMM d')] = 0;
  }
  txs?.forEach((tx) => {
    const d = format(new Date(tx.createdAt), 'MMM d');
    if (d in days) days[d] += tx.type === 'CREDIT' ? tx.amount : -tx.amount;
  });
  return Object.entries(days).map(([date, value]) => ({ date, value }));
}

function StatCard({ label, value, sub, loading }: { label: string; value: React.ReactNode; sub?: React.ReactNode; loading?: boolean }) {
  return (
    <Card className="p-6">
      <p className="stat-label mb-2">{label}</p>
      {loading ? <Skeleton className="h-9 w-36 mb-1" /> : <div className="stat-value">{value}</div>}
      {sub && <div className="mt-1 text-xs font-body text-muted">{sub}</div>}
    </Card>
  );
}

export default function OverviewPage() {
  const { data: wallet,  isLoading: wLoad }  = useWallet();
  const { data: account, isLoading: aLoad }  = usePointsAccount();
  const { data: txPage,  isLoading: txLoad } = useTransactions(0);

  const txs      = txPage?.content ?? [];
  const recent   = txs.slice(0, 6);
  const sparkline = buildSparkline(txs);
  const tier     = (account?.tier ?? 'BRONZE') as Tier;
  const progress = account ? tierProgress(account.totalPoints, tier) : 0;
  const tierColor = TIER_COLORS[tier];
  const [,nextMax] = TIER_RANGES[tier];
  const toNext = tier !== 'PLATINUM' ? nextMax - (account?.totalPoints ?? 0) : 0;

  return (
    <div className="page-enter space-y-8">
      {/* Page header */}
      <div>
        <h1 className="font-display text-2xl text-ink">Overview</h1>
        <p className="font-body text-sm text-muted mt-0.5">
          {format(new Date(), "EEEE, d MMMM yyyy")}
        </p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-3 gap-4 stagger">
        <StatCard
          label="Available balance"
          loading={wLoad}
          value={<Amount amount={wallet?.balance ?? 0} currency={wallet?.currency} size="lg" />}
          sub={wallet?.status === 'ACTIVE' ? '● Active' : wallet?.status}
        />
        <StatCard
          label="Points balance"
          loading={aLoad}
          value={<span className="font-mono text-3xl font-medium" style={{ color: tierColor }}>{account?.totalPoints?.toLocaleString() ?? '—'}</span>}
          sub={account ? <TierBadge tier={tier} size="sm" /> : null}
        />
        <StatCard
          label="Transactions (30d)"
          loading={txLoad}
          value={txPage?.totalElements ?? '—'}
          sub={toNext > 0 ? `${toNext.toLocaleString()} pts to next tier` : 'Platinum — max tier'}
        />
      </div>

      {/* Chart + Tier progress */}
      <div className="grid grid-cols-3 gap-4">
        {/* Sparkline */}
        <Card className="col-span-2 p-6">
          <p className="font-display text-sm font-semibold text-ink mb-4">7-day activity</p>
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={sparkline} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#0A5C3C" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#0A5C3C" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2DED8" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#B0ADA8', fontFamily: 'DM Mono' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#B0ADA8', fontFamily: 'DM Mono' }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ fontFamily: 'DM Sans', fontSize: 12, borderRadius: 8, border: '1px solid #E2DED8', boxShadow: '0 4px 16px rgba(0,0,0,0.08)' }}
                formatter={(v: number) => [fmt.currency(v), 'Net']}
              />
              <Area type="monotone" dataKey="value" stroke="#0A5C3C" strokeWidth={1.5} fill="url(#areaGrad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        {/* Tier card */}
        <Card className="p-6 flex flex-col gap-4">
          <p className="font-display text-sm font-semibold text-ink">Loyalty tier</p>
          <div className="flex-1 flex flex-col items-center justify-center gap-3">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center text-2xl font-display font-bold border-2"
              style={{ borderColor: tierColor, color: tierColor, backgroundColor: tierColor + '12' }}
            >
              {tier[0]}
            </div>
            <TierBadge tier={tier} />
          </div>
          <div>
            <div className="flex justify-between text-xs font-mono text-muted mb-1.5">
              <span>{account?.totalPoints?.toLocaleString() ?? 0} pts</span>
              <span>{progress}%</span>
            </div>
            <ProgressBar value={progress} color={tierColor} />
            {toNext > 0 && (
              <p className="font-body text-xs text-muted mt-2 text-center">
                {toNext.toLocaleString()} pts to next tier
              </p>
            )}
          </div>
        </Card>
      </div>

      {/* Recent transactions */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-base font-semibold text-ink">Recent transactions</h2>
          <Link to="/transactions" className="btn-ghost text-xs py-1 px-2">View all →</Link>
        </div>

        <Card>
          {txLoad ? (
            <div className="p-4 space-y-4">
              {[0, 1, 2].map((i) => (
                <div key={i} className="flex items-center gap-4">
                  <Skeleton className="w-10 h-10 rounded-xl" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-3.5 w-40" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                  <Skeleton className="h-4 w-20" />
                </div>
              ))}
            </div>
          ) : recent.length === 0 ? (
            <div className="py-12 text-center">
              <p className="font-body text-sm text-muted">No transactions yet</p>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {recent.map((tx) => (
                <div key={tx.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-canvas/50 transition-colors">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-base ${tx.type === 'CREDIT' ? 'bg-success-light text-success' : 'bg-canvas text-muted'}`}>
                    {TX_ICONS[tx.type]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-body text-sm text-ink truncate">{tx.description ?? tx.reference}</p>
                    <p className="font-mono text-xs text-muted">{fmt.date(tx.createdAt)}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`badge ${TX_STATUS_CLASS[tx.status]}`}>{tx.status}</span>
                    <Amount
                      amount={tx.amount}
                      size="sm"
                      positive={tx.type === 'CREDIT'}
                      negative={tx.type === 'DEBIT'}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
