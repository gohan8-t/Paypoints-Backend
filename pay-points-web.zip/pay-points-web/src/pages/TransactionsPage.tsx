import React, { useState, useCallback, useRef } from 'react';
import { useInfiniteTransactions } from '@/hooks/usePayPoints';
import { Card, Amount, Badge, Skeleton, EmptyState } from '@/components/ui';
import { fmt, TX_ICONS, TX_STATUS_CLASS } from '@/utils/helpers';
import { TxType } from '@/services/paypoints';

const FILTERS: { label: string; value: TxType | null }[] = [
  { label: 'All', value: null },
  { label: 'Credits', value: 'CREDIT' },
  { label: 'Debits', value: 'DEBIT' },
  { label: 'Transfers', value: 'TRANSFER' },
];

export default function TransactionsPage() {
  const [filter, setFilter] = useState<TxType | null>(null);
  const [search, setSearch] = useState('');

  const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isLoading } = useInfiniteTransactions();

  const allTx = data?.pages.flatMap((p) => p.content) ?? [];
  const filtered = allTx
    .filter((tx) => !filter || tx.type === filter)
    .filter((tx) => !search || tx.reference.toLowerCase().includes(search.toLowerCase())
      || tx.description?.toLowerCase().includes(search.toLowerCase()));

  // Sentinel div for infinite scroll
  const sentinelRef = useRef<HTMLDivElement>(null);
  const observer = useRef<IntersectionObserver | null>(null);
  const sentinelCallback = useCallback(
    (node: HTMLDivElement | null) => {
      if (observer.current) observer.current.disconnect();
      observer.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) fetchNextPage();
      });
      if (node) observer.current.observe(node);
    },
    [hasNextPage, isFetchingNextPage, fetchNextPage]
  );

  return (
    <div className="page-enter space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink">Transactions</h1>
        <p className="font-body text-sm text-muted mt-0.5">
          {data?.pages[0]?.totalElements ?? '—'} total transactions
        </p>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-xs">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-subtle" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
          </svg>
          <input
            type="text"
            placeholder="Search reference or description…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input-field pl-9 text-sm py-2"
          />
        </div>

        {/* Type filters */}
        <div className="flex gap-1.5">
          {FILTERS.map((f) => (
            <button
              key={f.label}
              onClick={() => setFilter(f.value)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-body border transition-all duration-150 ${
                filter === f.value
                  ? 'bg-ink text-white border-ink'
                  : 'bg-surface text-muted border-border hover:border-ink/30 hover:text-ink'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <Card className="overflow-hidden">
        {/* Header */}
        <div className="grid grid-cols-[2fr_1fr_1fr_1fr] gap-4 px-5 py-3 border-b border-border bg-canvas">
          {['Transaction', 'Type', 'Status', 'Amount'].map((h) => (
            <span key={h} className="font-body text-[10px] uppercase tracking-widest text-muted">{h}</span>
          ))}
        </div>

        {isLoading ? (
          <div className="divide-y divide-border">
            {[0, 1, 2, 3, 4].map((i) => (
              <div key={i} className="grid grid-cols-[2fr_1fr_1fr_1fr] gap-4 px-5 py-4 items-center">
                <div className="flex items-center gap-3">
                  <Skeleton className="w-9 h-9 rounded-xl" />
                  <div className="space-y-1.5">
                    <Skeleton className="h-3 w-32" />
                    <Skeleton className="h-2.5 w-20" />
                  </div>
                </div>
                <Skeleton className="h-5 w-16 rounded-full" />
                <Skeleton className="h-5 w-20 rounded-full" />
                <Skeleton className="h-4 w-24" />
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState
            icon="📋"
            title={search ? 'No matching transactions' : 'No transactions yet'}
            description={search ? 'Try a different search term' : 'Transactions will appear here once you start paying'}
          />
        ) : (
          <div className="divide-y divide-border">
            {filtered.map((tx) => (
              <div
                key={tx.id}
                className="grid grid-cols-[2fr_1fr_1fr_1fr] gap-4 px-5 py-3.5 items-center hover:bg-canvas/60 transition-colors"
              >
                {/* Description */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm flex-shrink-0 ${
                    tx.type === 'CREDIT' ? 'bg-success-light text-success' : 'bg-canvas text-muted'
                  }`}>
                    {TX_ICONS[tx.type]}
                  </div>
                  <div className="min-w-0">
                    <p className="font-body text-sm text-ink truncate">{tx.description ?? tx.reference}</p>
                    <p className="font-mono text-[10px] text-subtle">{fmt.date(tx.createdAt)}</p>
                  </div>
                </div>

                {/* Type */}
                <span className={`badge ${
                  tx.type === 'CREDIT' ? 'badge-success' :
                  tx.type === 'DEBIT'  ? 'badge-neutral' : 'badge-neutral'
                }`}>
                  {tx.type}
                </span>

                {/* Status */}
                <span className={`badge ${TX_STATUS_CLASS[tx.status]}`}>{tx.status}</span>

                {/* Amount */}
                <Amount
                  amount={tx.amount}
                  size="sm"
                  positive={tx.type === 'CREDIT'}
                  negative={tx.type === 'DEBIT'}
                />
              </div>
            ))}
          </div>
        )}

        {/* Infinite scroll sentinel */}
        <div ref={sentinelCallback} className="h-4" />

        {isFetchingNextPage && (
          <div className="flex justify-center py-4">
            <div className="w-5 h-5 border-2 border-border border-t-accent rounded-full animate-spin" />
          </div>
        )}
      </Card>
    </div>
  );
}
