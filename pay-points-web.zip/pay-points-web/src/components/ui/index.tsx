import React from 'react';
import clsx from 'clsx';
import { Tier, TIER_COLORS } from '@/utils/helpers';

// ── Button ────────────────────────────────────────────────────────────────────
interface BtnProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
}
export function Button({ variant = 'primary', size = 'md', loading, children, className, disabled, ...rest }: BtnProps) {
  const base = 'inline-flex items-center justify-center gap-2 font-body font-medium rounded-lg transition-all duration-150 active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed select-none';
  const sizes = { sm: 'px-3.5 py-1.5 text-xs', md: 'px-5 py-2.5 text-sm', lg: 'px-6 py-3 text-base' };
  const variants = {
    primary:   'bg-accent text-white hover:bg-accent/90',
    secondary: 'bg-surface text-ink border border-border hover:bg-canvas',
    ghost:     'text-accent hover:bg-accent-light',
    danger:    'bg-danger-light text-danger border border-danger/20 hover:bg-danger/10',
  };
  return (
    <button className={clsx(base, sizes[size], variants[variant], className)} disabled={disabled || loading} {...rest}>
      {loading ? <Spinner size={size === 'lg' ? 18 : 14} /> : children}
    </button>
  );
}

// ── Spinner ───────────────────────────────────────────────────────────────────
export function Spinner({ size = 16, color = 'currentColor' }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className="animate-spin">
      <circle cx="12" cy="12" r="10" stroke={color} strokeWidth="3" strokeOpacity="0.2" />
      <path d="M12 2a10 10 0 0 1 10 10" stroke={color} strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

// ── Card ──────────────────────────────────────────────────────────────────────
interface CardProps { children: React.ReactNode; className?: string; onClick?: () => void; hover?: boolean; }
export function Card({ children, className, onClick, hover }: CardProps) {
  return (
    <div
      onClick={onClick}
      className={clsx('card', hover && 'cursor-pointer hover:shadow-float transition-shadow duration-200', className)}
    >
      {children}
    </div>
  );
}

// ── Badge ─────────────────────────────────────────────────────────────────────
export function Badge({ children, variant = 'neutral' }: { children: React.ReactNode; variant?: 'gold' | 'success' | 'danger' | 'neutral' }) {
  return <span className={`badge badge-${variant}`}>{children}</span>;
}

// ── TierBadge ─────────────────────────────────────────────────────────────────
export function TierBadge({ tier, size = 'md' }: { tier: Tier; size?: 'sm' | 'md' }) {
  const color = TIER_COLORS[tier];
  const px = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs';
  return (
    <span
      className={clsx('inline-flex items-center gap-1 rounded-full font-mono font-medium border', px)}
      style={{ color, borderColor: color + '40', backgroundColor: color + '12' }}
    >
      ◆ {tier}
    </span>
  );
}

// ── Input ─────────────────────────────────────────────────────────────────────
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> { label?: string; error?: string; }
export function Input({ label, error, className, ...rest }: InputProps) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="font-body text-xs text-muted uppercase tracking-widest">{label}</label>}
      <input className={clsx('input-field', error && 'border-danger/60 focus:ring-danger/20', className)} {...rest} />
      {error && <p className="text-xs text-danger font-body">{error}</p>}
    </div>
  );
}

// ── Skeleton ──────────────────────────────────────────────────────────────────
export function Skeleton({ className }: { className?: string }) {
  return <div className={clsx('animate-pulse bg-border rounded', className)} />;
}

// ── Amount Display ────────────────────────────────────────────────────────────
interface AmountProps { amount: number; currency?: string; size?: 'sm' | 'md' | 'lg' | 'hero'; muted?: boolean; positive?: boolean; negative?: boolean; }
export function Amount({ amount, currency = 'ZAR', size = 'md', muted, positive, negative }: AmountProps) {
  const [whole, dec] = Math.abs(amount).toFixed(2).split('.');
  const color = positive ? 'text-success' : negative ? 'text-danger' : muted ? 'text-muted' : 'text-ink';
  const sizes = {
    sm:   { curr: 'text-[10px]', whole: 'text-base',  dec: 'text-xs' },
    md:   { curr: 'text-xs',     whole: 'text-xl',    dec: 'text-sm' },
    lg:   { curr: 'text-sm',     whole: 'text-3xl',   dec: 'text-lg' },
    hero: { curr: 'text-base',   whole: 'text-5xl',   dec: 'text-2xl' },
  }[size];
  return (
    <span className={clsx('font-mono tracking-tight', color)}>
      {(positive || negative) && <span className="mr-0.5">{positive ? '+' : '−'}</span>}
      <span className={clsx(sizes.curr, 'opacity-50')}>{currency} </span>
      <span className={clsx(sizes.whole, 'font-medium')}>{whole}</span>
      <span className={clsx(sizes.dec, 'opacity-60')}>.<span>{dec}</span></span>
    </span>
  );
}

// ── Divider ───────────────────────────────────────────────────────────────────
export function Divider({ className }: { className?: string }) {
  return <hr className={clsx('border-border', className)} />;
}

// ── Empty state ───────────────────────────────────────────────────────────────
export function EmptyState({ icon, title, description }: { icon: string; title: string; description?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3 text-center">
      <span className="text-4xl opacity-40">{icon}</span>
      <p className="font-display text-base text-ink">{title}</p>
      {description && <p className="font-body text-sm text-muted max-w-xs">{description}</p>}
    </div>
  );
}

// ── Progress bar ──────────────────────────────────────────────────────────────
export function ProgressBar({ value, color = '#0A5C3C', className }: { value: number; color?: string; className?: string }) {
  return (
    <div className={clsx('h-1.5 bg-border rounded-full overflow-hidden', className)}>
      <div
        className="h-full rounded-full transition-all duration-700"
        style={{ width: `${Math.min(value, 100)}%`, backgroundColor: color }}
      />
    </div>
  );
}
