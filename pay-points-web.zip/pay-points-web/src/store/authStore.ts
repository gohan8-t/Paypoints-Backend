import { create } from 'zustand';
import { api } from '../services/api';
import { AuthService, TokenResponse } from '../services/paypoints';

interface AuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login:    (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, fullName: string, phone?: string) => Promise<void>;
  logout:   () => void;
  init:     () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  isAuthenticated: false,
  isLoading: true,
  error: null,

  init: () => {
    set({ isAuthenticated: api.hasToken(), isLoading: false });
  },

  login: async (email, password) => {
    set({ isLoading: true, error: null });
    try {
      const res: TokenResponse = await AuthService.login(email, password);
      api.saveTokens(res.accessToken, res.refreshToken);
      set({ isAuthenticated: true, isLoading: false });
    } catch (e: any) {
      set({ error: e?.response?.data?.message ?? 'Login failed', isLoading: false });
      throw e;
    }
  },

  register: async (email, password, fullName, phone) => {
    set({ isLoading: true, error: null });
    try {
      const res: TokenResponse = await AuthService.register(email, password, fullName, phone);
      api.saveTokens(res.accessToken, res.refreshToken);
      set({ isAuthenticated: true, isLoading: false });
    } catch (e: any) {
      set({ error: e?.response?.data?.message ?? 'Registration failed', isLoading: false });
      throw e;
    }
  },

  logout: () => {
    api.clearTokens();
    set({ isAuthenticated: false });
  },
}));
