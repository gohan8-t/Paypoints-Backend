import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';

const BASE_URL = import.meta.env.VITE_API_URL ?? '/api/v1';

const TOKEN_KEY   = 'pp_access_token';
const REFRESH_KEY = 'pp_refresh_token';

class ApiClient {
  private http: AxiosInstance;
  private refreshing = false;

  constructor() {
    this.http = axios.create({
      baseURL: BASE_URL,
      timeout: 12_000,
      headers: { 'Content-Type': 'application/json' },
    });

    this.http.interceptors.request.use((config) => {
      const token = localStorage.getItem(TOKEN_KEY);
      if (token) config.headers.Authorization = `Bearer ${token}`;
      return config;
    });

    this.http.interceptors.response.use(
      (res) => res,
      async (err) => {
        const original = err.config;
        if (err.response?.status === 401 && !original._retry && !this.refreshing) {
          original._retry = true;
          this.refreshing = true;
          try {
            const refresh = localStorage.getItem(REFRESH_KEY);
            if (refresh) {
              const { data } = await axios.post(`${BASE_URL}/auth/refresh?refreshToken=${refresh}`);
              this.saveTokens(data.accessToken, data.refreshToken);
              original.headers.Authorization = `Bearer ${data.accessToken}`;
              return this.http(original);
            }
          } catch {
            this.clearTokens();
            window.location.href = '/login';
          } finally {
            this.refreshing = false;
          }
        }
        return Promise.reject(err);
      }
    );
  }

  saveTokens(access: string, refresh: string) {
    localStorage.setItem(TOKEN_KEY, access);
    localStorage.setItem(REFRESH_KEY, refresh);
  }

  clearTokens() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(REFRESH_KEY);
  }

  hasToken() {
    return !!localStorage.getItem(TOKEN_KEY);
  }

  get<T>(url: string, config?: AxiosRequestConfig) {
    return this.http.get<T>(url, config).then((r) => r.data);
  }
  post<T>(url: string, data?: unknown, config?: AxiosRequestConfig) {
    return this.http.post<T>(url, data, config).then((r) => r.data);
  }
  put<T>(url: string, data?: unknown) {
    return this.http.put<T>(url, data).then((r) => r.data);
  }
  delete<T>(url: string) {
    return this.http.delete<T>(url).then((r) => r.data);
  }
}

export const api = new ApiClient();
