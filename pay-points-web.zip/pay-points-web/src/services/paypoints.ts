import { api } from './api';

export type WalletStatus    = 'ACTIVE' | 'SUSPENDED' | 'CLOSED';
export type TxType          = 'CREDIT' | 'DEBIT' | 'TRANSFER';
export type TxStatus        = 'PENDING' | 'COMPLETED' | 'FAILED' | 'REVERSED';
export type Tier            = 'BRONZE' | 'SILVER' | 'GOLD' | 'PLATINUM';
export type RedemptionStatus = 'PENDING' | 'COMPLETED' | 'FAILED';

export interface Wallet {
  id: string; userId: string; balance: number;
  currency: string; status: WalletStatus; createdAt: string;
}

export interface Transaction {
  id: string; walletId: string; type: TxType; amount: number;
  reference: string; status: TxStatus; description?: string; createdAt: string;
}

export interface PageResponse<T> {
  content: T[]; totalElements: number; totalPages: number;
  number: number; size: number;
}

export interface PointsAccount {
  id: string; userId: string; totalPoints: number; tier: Tier; updatedAt: string;
}

export interface Reward {
  id: string; name: string; description: string; costPoints: number;
  category: string; imageUrl?: string; stock: number;
}

export interface Redemption {
  id: string; rewardId: string; pointsSpent: number;
  status: RedemptionStatus; redeemedAt: string;
}

export interface TokenResponse {
  accessToken: string; refreshToken: string; tokenType: string; expiresIn: number;
}

export const WalletService = {
  get: ()                                        => api.get<Wallet>('/wallet'),
  credit: (amount: number, ref: string, desc?: string) =>
    api.post<Transaction>('/wallet/credit', { amount, reference: ref, description: desc }),
  debit:  (amount: number, ref: string, desc?: string) =>
    api.post<Transaction>('/wallet/debit',  { amount, reference: ref, description: desc }),
  transactions: (page = 0, size = 20) =>
    api.get<PageResponse<Transaction>>(`/wallet/transactions?page=${page}&size=${size}`),
};

export const RewardsService = {
  account: ()              => api.get<PointsAccount>('/rewards/account'),
  list: (cat?: string)     => api.get<Reward[]>(`/rewards${cat ? `?category=${cat}` : ''}`),
  redeem: (id: string)     => api.post<Redemption>(`/rewards/redeem?rewardId=${id}`),
  history: (page = 0)      =>
    api.get<PageResponse<Redemption>>(`/rewards/history?page=${page}`),
};

export const AuthService = {
  login:    (email: string, password: string) =>
    api.post<TokenResponse>('/auth/login', { email, password }),
  register: (email: string, password: string, fullName: string, phone?: string) =>
    api.post<TokenResponse>('/auth/register', { email, password, fullName, phone }),
};
