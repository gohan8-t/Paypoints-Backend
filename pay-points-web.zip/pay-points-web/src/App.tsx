import React, { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';

import AuthGuard    from './components/AuthGuard';
import AppLayout    from './layouts/AppLayout';
import LoginPage    from './pages/LoginPage';
import OverviewPage from './pages/OverviewPage';
import PayPage      from './pages/PayPage';
import RewardsPage  from './pages/RewardsPage';
import TransactionsPage from './pages/TransactionsPage';
import ProfilePage  from './pages/ProfilePage';

export default function App() {
  const init = useAuthStore((s) => s.init);
  useEffect(() => { init(); }, [init]);

  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />

      <Route element={<AuthGuard />}>
        <Route element={<AppLayout />}>
          <Route index element={<OverviewPage />} />
          <Route path="pay"          element={<PayPage />} />
          <Route path="rewards"      element={<RewardsPage />} />
          <Route path="transactions" element={<TransactionsPage />} />
          <Route path="profile"      element={<ProfilePage />} />
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
