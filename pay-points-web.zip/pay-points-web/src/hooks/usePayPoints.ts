import { useQuery, useMutation, useQueryClient, useInfiniteQuery } from '@tanstack/react-query';
import { WalletService, RewardsService } from '../services/paypoints';

export const useWallet = () =>
  useQuery({ queryKey: ['wallet'], queryFn: WalletService.get, staleTime: 30_000 });

export const useTransactions = (page = 0) =>
  useQuery({
    queryKey: ['transactions', page],
    queryFn: () => WalletService.transactions(page, 20),
    staleTime: 15_000,
  });

export const useInfiniteTransactions = () =>
  useInfiniteQuery({
    queryKey: ['all-transactions'],
    queryFn: ({ pageParam = 0 }) => WalletService.transactions(pageParam as number, 20),
    getNextPageParam: (last) => last.number < last.totalPages - 1 ? last.number + 1 : undefined,
    initialPageParam: 0,
  });

export const useDebitWallet = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ amount, ref, desc }: { amount: number; ref: string; desc?: string }) =>
      WalletService.debit(amount, ref, desc),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['wallet'] });
      qc.invalidateQueries({ queryKey: ['transactions'] });
      qc.invalidateQueries({ queryKey: ['points-account'] });
    },
  });
};

export const useCreditWallet = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ amount, ref, desc }: { amount: number; ref: string; desc?: string }) =>
      WalletService.credit(amount, ref, desc),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['wallet'] });
      qc.invalidateQueries({ queryKey: ['transactions'] });
    },
  });
};

export const usePointsAccount = () =>
  useQuery({ queryKey: ['points-account'], queryFn: RewardsService.account, staleTime: 30_000 });

export const useRewards = (category?: string) =>
  useQuery({
    queryKey: ['rewards', category],
    queryFn: () => RewardsService.list(category),
    staleTime: 60_000,
  });

export const useRedeemReward = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => RewardsService.redeem(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['points-account'] });
      qc.invalidateQueries({ queryKey: ['rewards'] });
    },
  });
};

export const useRedemptionHistory = () =>
  useInfiniteQuery({
    queryKey: ['redemption-history'],
    queryFn: ({ pageParam = 0 }) => RewardsService.history(pageParam as number),
    getNextPageParam: (last) => last.number < last.totalPages - 1 ? last.number + 1 : undefined,
    initialPageParam: 0,
  });
