# PayPoints Web App — Quickstart

React 18 + TypeScript + Vite + Tailwind CSS.

## Prerequisites
- Node.js 20+
- Backend running on port 8080

## 1. Install
```bash
cd pay-points-web
npm install
```

## 2. Configure
```bash
cp .env.example .env.local
# Edit VITE_API_URL if your backend is not on localhost:8080
```

## 3. Run
```bash
npm run dev
# → http://localhost:3000
```

## 4. Build for production
```bash
npm run build
npm run preview   # preview the built output
```

## Project structure
```
src/
├── pages/
│   ├── LoginPage.tsx         # Auth: login + register split-screen
│   ├── OverviewPage.tsx      # Dashboard: balance, chart, recent txns
│   ├── PayPage.tsx           # Send payment with quick amounts
│   ├── RewardsPage.tsx       # Points, tier banner, reward catalogue
│   ├── TransactionsPage.tsx  # Infinite-scroll table + search/filter
│   └── ProfilePage.tsx       # Settings, tier journey, logout
├── components/
│   ├── ui/index.tsx          # Button, Card, Badge, Input, Amount, etc.
│   └── AuthGuard.tsx         # Protected route wrapper
├── layouts/
│   ├── AppLayout.tsx         # Sidebar + main content
│   └── Sidebar.tsx           # Nav, wallet card, logout
├── services/
│   ├── api.ts                # Axios client + JWT refresh interceptor
│   └── paypoints.ts          # Domain types + service objects
├── store/authStore.ts        # Zustand auth state
├── hooks/usePayPoints.ts     # React Query hooks for all data
├── utils/helpers.ts          # Formatters, tier utils, constants
└── index.css                 # Tailwind + global styles + animations
```

## Design system
- **Canvas**: warm off-white `#F5F2ED` — page background
- **Surface**: pure white — cards, sidebar
- **Accent**: deep forest green `#0A5C3C` — CTAs, active states
- **Display font**: Syne (bold, editorial feel)
- **Body font**: DM Sans (clean, readable)
- **Mono font**: DM Mono (amounts, references, codes)

## Auth flow
1. User logs in → JWT stored in `localStorage` (pp_access_token)
2. All requests attach `Authorization: Bearer <token>` via Axios interceptor
3. On 401 → silent refresh using `pp_refresh_token`
4. On refresh failure → redirect to `/login`
5. `AuthGuard` wraps all protected routes — unauthenticated users redirect to `/login`

## Connecting to backend
The Vite dev server proxies `/api` to `http://localhost:8080` (configured in `vite.config.ts`).

Make sure your backend is running:
```bash
# From pay-points-backend/
docker compose up -d postgres kafka zookeeper redis
mvn spring-boot:run
```
