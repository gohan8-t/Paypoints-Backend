# Backend Quickstart

## Prerequisites
- Java 21+
- Maven 3.9+
- Docker & Docker Compose

## 1. Start Infrastructure
```bash
docker compose up -d postgres kafka zookeeper redis
```
Wait ~15 seconds for Kafka + Postgres to be ready.

## 2. Configure Environment
```bash
cp .env.example .env
# Edit .env — at minimum set a real JWT_SECRET:
# openssl rand -base64 32
```

## 3. Run the App
```bash
./mvnw spring-boot:run -Dspring-boot.run.profiles=dev
# OR
mvn spring-boot:run
```
App starts on http://localhost:8080/api/v1

## 4. Verify
```bash
curl http://localhost:8080/api/v1/actuator/health
# -> {"status":"UP"}
```

## 5. Register + Get Token
```bash
curl -X POST http://localhost:8080/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"dev@test.com","password":"password123","fullName":"Dev User"}'
# -> {"accessToken":"eyJ...","refreshToken":"eyJ...","tokenType":"Bearer","expiresIn":86400000}
```

## 6. Use Token
```bash
TOKEN="eyJ..."
curl http://localhost:8080/api/v1/wallet \
  -H "Authorization: Bearer $TOKEN"
```

## Run Tests
```bash
mvn test
```
Tests use Testcontainers — Docker must be running.

## API Endpoints

### Auth
| Method | Path | Description |
|--------|------|-------------|
| POST | /auth/register | Register new user |
| POST | /auth/login | Login |
| POST | /auth/refresh | Refresh token |

### Wallet (🔒 JWT required)
| Method | Path | Description |
|--------|------|-------------|
| GET | /wallet | Get wallet balance |
| POST | /wallet/credit | Credit wallet |
| POST | /wallet/debit | Debit wallet |
| GET | /wallet/transactions | Transaction history |

### Rewards (🔒 JWT required)
| Method | Path | Description |
|--------|------|-------------|
| GET | /rewards/account | Points balance + tier |
| GET | /rewards | List available rewards |
| POST | /rewards/redeem?rewardId= | Redeem reward |
| GET | /rewards/history | Redemption history |

## Architecture Notes
- **Pessimistic locking** on wallet + points balance updates (prevents double-spend)
- **Idempotent transactions** — duplicate `reference` values are rejected
- **Kafka events** published on every payment + points change
- **Automatic points** awarded via `PointsEarnedListener` (10pts per R1 spent)
- **Tier upgrades** detected and published on every points change
