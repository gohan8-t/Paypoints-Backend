CREATE TABLE points_accounts (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
    total_points  BIGINT NOT NULL DEFAULT 0 CHECK (total_points >= 0),
    tier          VARCHAR(20) NOT NULL DEFAULT 'BRONZE',
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE points_transactions (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    account_id  UUID NOT NULL REFERENCES points_accounts(id),
    delta       BIGINT NOT NULL,
    reason      VARCHAR(100) NOT NULL,
    ref_id      UUID,
    expires_at  TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE rewards (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name        VARCHAR(255) NOT NULL,
    description TEXT,
    cost_points BIGINT NOT NULL CHECK (cost_points > 0),
    category    VARCHAR(50),
    image_url   TEXT,
    stock       INT NOT NULL DEFAULT -1,
    active      BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE reward_redemptions (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id      UUID NOT NULL REFERENCES users(id),
    reward_id    UUID NOT NULL REFERENCES rewards(id),
    points_spent BIGINT NOT NULL,
    status       VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    redeemed_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_points_tx_account ON points_transactions(account_id, created_at DESC);
CREATE INDEX idx_redemptions_user ON reward_redemptions(user_id, redeemed_at DESC);
CREATE INDEX idx_rewards_category_active ON rewards(category) WHERE active = TRUE;

-- Seed rewards
INSERT INTO rewards (name, description, cost_points, category, stock) VALUES
    ('R50 Airtime',     '50 ZAR airtime top-up',           500,  'AIRTIME',       -1),
    ('R100 Airtime',    '100 ZAR airtime top-up',          1000, 'AIRTIME',       -1),
    ('Coffee Voucher',  'Single espresso at partner cafes', 200, 'FOOD',         100),
    ('R100 Cashback',   'Direct cashback to your wallet',  1000, 'CASHBACK',      -1),
    ('Netflix 1 Month', 'Netflix standard plan voucher',   3000, 'ENTERTAINMENT', 50),
    ('Uber R75 Credit', 'Uber ride credit',                 800, 'TRANSPORT',     -1);
