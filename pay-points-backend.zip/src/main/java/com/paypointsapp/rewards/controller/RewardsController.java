package com.paypointsapp.rewards.controller;

import com.paypointsapp.rewards.dto.*;
import com.paypointsapp.rewards.service.RewardsService;
import com.paypointsapp.security.UserPrincipal;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/rewards")
@RequiredArgsConstructor
public class RewardsController {

    private final RewardsService rewardsService;

    @GetMapping("/account")
    public ResponseEntity<PointsAccountDto> getAccount(@AuthenticationPrincipal UserPrincipal user) {
        return ResponseEntity.ok(rewardsService.getAccount(user.id()));
    }

    @GetMapping
    public ResponseEntity<List<RewardDto>> listRewards(
            @RequestParam(required = false) String category) {
        return ResponseEntity.ok(rewardsService.listRewards(category));
    }

    @PostMapping("/redeem")
    public ResponseEntity<RedemptionDto> redeem(@AuthenticationPrincipal UserPrincipal user,
                                                 @RequestParam @NotNull UUID rewardId) {
        return ResponseEntity.ok(rewardsService.redeemReward(user.id(), rewardId));
    }

    @GetMapping("/history")
    public ResponseEntity<Page<RedemptionDto>> history(
            @AuthenticationPrincipal UserPrincipal user,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(rewardsService.getHistory(user.id(), page, size));
    }
}
