package com.paypointsapp.rewards.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "reward_redemptions")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class RewardRedemption {

    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "user_id", nullable = false)
    private UUID userId;

    @Column(name = "reward_id", nullable = false)
    private UUID rewardId;

    @Column(name = "points_spent", nullable = false)
    private long pointsSpent;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RedemptionStatus status = RedemptionStatus.PENDING;

    @Column(name = "redeemed_at", nullable = false, updatable = false)
    private Instant redeemedAt = Instant.now();

    public enum RedemptionStatus { PENDING, COMPLETED, FAILED, REVERSED }
}
