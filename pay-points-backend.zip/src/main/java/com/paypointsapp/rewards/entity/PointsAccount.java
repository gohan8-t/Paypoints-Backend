package com.paypointsapp.rewards.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "points_accounts")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PointsAccount {

    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "user_id", nullable = false, unique = true)
    private UUID userId;

    @Column(name = "total_points", nullable = false)
    private long totalPoints = 0L;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Tier tier = Tier.BRONZE;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Instant updatedAt;

    public void addPoints(long points) {
        this.totalPoints += points;
        recalculateTier();
    }

    public void deductPoints(long points) {
        if (this.totalPoints < points) throw new IllegalStateException("Insufficient points");
        this.totalPoints -= points;
        recalculateTier();
    }

    public void recalculateTier() {
        if      (totalPoints >= 15_000) this.tier = Tier.PLATINUM;
        else if (totalPoints >= 5_000)  this.tier = Tier.GOLD;
        else if (totalPoints >= 1_000)  this.tier = Tier.SILVER;
        else                            this.tier = Tier.BRONZE;
    }

    public static PointsAccount createFor(UUID userId) {
        return PointsAccount.builder().userId(userId).totalPoints(0).tier(Tier.BRONZE).build();
    }

    public enum Tier { BRONZE, SILVER, GOLD, PLATINUM }
}
