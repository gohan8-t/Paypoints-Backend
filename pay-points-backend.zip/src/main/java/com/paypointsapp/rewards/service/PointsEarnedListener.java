package com.paypointsapp.rewards.service;

import com.paypointsapp.wallet.event.PaymentEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Listens to payment events and automatically awards points.
 * 10 pts per R1 spent (configurable via app.rewards.points-per-zar).
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class PointsEarnedListener {

    private final RewardsService rewardsService;

    @Value("${app.rewards.points-per-zar:10}")
    private int pointsPerZar;

    @KafkaListener(topics = "${app.kafka.topics.payment-events}", groupId = "points-earner")
    public void onPaymentEvent(PaymentEvent event) {
        if (!"DEBIT".equals(event.type())) return;   // Only award pts on spend

        long pts = event.amount().longValue() * pointsPerZar;
        if (pts <= 0) return;

        try {
            rewardsService.earnPoints(
                UUID.fromString(event.userId()), pts,
                "PAYMENT:" + event.reference(),
                UUID.fromString(event.walletId())
            );
        } catch (Exception e) {
            log.error("Failed to award points for payment {}: {}", event.reference(), e.getMessage());
        }
    }
}
