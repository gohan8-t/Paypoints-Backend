package com.paypointsapp.rewards.service;

import com.paypointsapp.exception.InsufficientPointsException;
import com.paypointsapp.exception.ResourceNotFoundException;
import com.paypointsapp.rewards.dto.*;
import com.paypointsapp.rewards.entity.*;
import com.paypointsapp.rewards.event.RewardEventPublisher;
import com.paypointsapp.rewards.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class RewardsService {

    private final PointsAccountRepository pointsAccountRepository;
    private final RewardRepository rewardRepository;
    private final RedemptionRepository redemptionRepository;
    private final RewardEventPublisher eventPublisher;
    private final RewardsMapper rewardsMapper;

    @Value("${app.rewards.points-per-zar:10}")
    private int pointsPerZar;

    @Transactional(readOnly = true)
    public PointsAccountDto getAccount(UUID userId) {
        PointsAccount account = pointsAccountRepository.findByUserId(userId)
            .orElseThrow(() -> new ResourceNotFoundException("Points account not found for user: " + userId));
        return rewardsMapper.toDto(account);
    }

    @Transactional
    public PointsAccountDto getOrCreateAccount(UUID userId) {
        return rewardsMapper.toDto(
            pointsAccountRepository.findByUserId(userId)
                .orElseGet(() -> pointsAccountRepository.save(PointsAccount.createFor(userId)))
        );
    }

    @Transactional
    public void earnPoints(UUID userId, long points, String reason, UUID refId) {
        PointsAccount account = pointsAccountRepository.findByUserIdForUpdate(userId)
            .orElseGet(() -> pointsAccountRepository.save(PointsAccount.createFor(userId)));

        Tier prevTier = account.getTier();
        account.addPoints(points);
        pointsAccountRepository.save(account);

        log.info("User {} earned {} pts (reason={}). Total: {}, Tier: {}", userId, points, reason,
            account.getTotalPoints(), account.getTier());

        eventPublisher.publishPointsEarned(userId, points, account.getTotalPoints(), account.getTier());

        if (account.getTier() != prevTier) {
            log.info("User {} upgraded tier: {} -> {}", userId, prevTier, account.getTier());
            eventPublisher.publishTierUpgrade(userId, prevTier, account.getTier());
        }
    }

    @Transactional
    public RedemptionDto redeemReward(UUID userId, UUID rewardId) {
        Reward reward = rewardRepository.findById(rewardId)
            .orElseThrow(() -> new ResourceNotFoundException("Reward not found: " + rewardId));

        if (!reward.isActive()) throw new IllegalStateException("Reward is no longer available");
        if (reward.getStock() == 0) throw new IllegalStateException("Reward is out of stock");

        PointsAccount account = pointsAccountRepository.findByUserIdForUpdate(userId)
            .orElseThrow(() -> new ResourceNotFoundException("Points account not found: " + userId));

        if (account.getTotalPoints() < reward.getCostPoints()) {
            throw new InsufficientPointsException(
                "Need " + reward.getCostPoints() + " pts, have " + account.getTotalPoints());
        }

        account.deductPoints(reward.getCostPoints());
        pointsAccountRepository.save(account);

        if (reward.getStock() > 0) {
            reward.setStock(reward.getStock() - 1);
            if (reward.getStock() == 0) reward.setActive(false);
            rewardRepository.save(reward);
        }

        RewardRedemption redemption = RewardRedemption.builder()
            .userId(userId).rewardId(rewardId)
            .pointsSpent(reward.getCostPoints())
            .status(RewardRedemption.RedemptionStatus.COMPLETED)
            .build();
        redemptionRepository.save(redemption);

        eventPublisher.publishRewardRedeemed(userId, rewardId, reward.getCostPoints());
        return rewardsMapper.redemptionToDto(redemption);
    }

    @Transactional(readOnly = true)
    public List<RewardDto> listRewards(String category) {
        List<Reward> rewards = category != null
            ? rewardRepository.findByCategoryAndActiveTrueOrderByCostPointsAsc(category)
            : rewardRepository.findByActiveTrueOrderByCostPointsAsc();
        return rewards.stream().map(rewardsMapper::rewardToDto).toList();
    }

    @Transactional(readOnly = true)
    public Page<RedemptionDto> getHistory(UUID userId, int page, int size) {
        return redemptionRepository
            .findByUserIdOrderByRedeemedAtDesc(userId, PageRequest.of(page, size))
            .map(rewardsMapper::redemptionToDto);
    }
}
