package com.paypointsapp.rewards.service;

import com.paypointsapp.rewards.dto.*;
import com.paypointsapp.rewards.entity.*;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface RewardsMapper {
    PointsAccountDto toDto(PointsAccount account);
    RewardDto rewardToDto(Reward reward);
    RedemptionDto redemptionToDto(RewardRedemption redemption);
}
