package com.paypointsapp.rewards.dto;

import com.paypointsapp.rewards.entity.PointsAccount.Tier;
import java.time.Instant;
import java.util.UUID;

public record PointsAccountDto(UUID id, UUID userId, long totalPoints, Tier tier, Instant updatedAt) {}
