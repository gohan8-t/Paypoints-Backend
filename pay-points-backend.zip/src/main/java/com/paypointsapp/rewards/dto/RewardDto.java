package com.paypointsapp.rewards.dto;

import java.util.UUID;

public record RewardDto(UUID id, String name, String description, long costPoints,
                        String category, String imageUrl, int stock) {}
