package com.paypointsapp.rewards.dto;

import com.paypointsapp.rewards.entity.RewardRedemption.RedemptionStatus;
import java.time.Instant;
import java.util.UUID;

public record RedemptionDto(UUID id, UUID rewardId, long pointsSpent,
                            RedemptionStatus status, Instant redeemedAt) {}
