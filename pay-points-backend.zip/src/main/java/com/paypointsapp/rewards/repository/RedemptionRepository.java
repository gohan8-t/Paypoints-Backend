package com.paypointsapp.rewards.repository;

import com.paypointsapp.rewards.entity.RewardRedemption;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface RedemptionRepository extends JpaRepository<RewardRedemption, UUID> {
    Page<RewardRedemption> findByUserIdOrderByRedeemedAtDesc(UUID userId, Pageable pageable);
}
