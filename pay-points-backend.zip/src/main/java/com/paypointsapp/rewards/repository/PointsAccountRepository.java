package com.paypointsapp.rewards.repository;

import com.paypointsapp.rewards.entity.PointsAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import jakarta.persistence.LockModeType;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface PointsAccountRepository extends JpaRepository<PointsAccount, UUID> {
    Optional<PointsAccount> findByUserId(UUID userId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT p FROM PointsAccount p WHERE p.userId = :userId")
    Optional<PointsAccount> findByUserIdForUpdate(UUID userId);
}
