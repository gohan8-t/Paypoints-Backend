package com.paypointsapp.rewards.event;

import com.paypointsapp.rewards.entity.PointsAccount.Tier;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class RewardEventPublisher {

    private final KafkaTemplate<String, Object> kafkaTemplate;

    @Value("${app.kafka.topics.point-events}")  private String pointTopic;
    @Value("${app.kafka.topics.reward-events}") private String rewardTopic;

    public void publishPointsEarned(UUID userId, long delta, long total, Tier tier) {
        kafkaTemplate.send(pointTopic, userId.toString(),
            new PointsEarnedEvent(UUID.randomUUID().toString(), userId.toString(), delta, total, tier.name(), Instant.now()));
    }

    public void publishTierUpgrade(UUID userId, Tier prev, Tier next) {
        log.info("Tier upgrade event: user={} {} -> {}", userId, prev, next);
        kafkaTemplate.send(rewardTopic, userId.toString(),
            new TierUpgradeEvent(userId.toString(), prev.name(), next.name(), Instant.now()));
    }

    public void publishRewardRedeemed(UUID userId, UUID rewardId, long pointsSpent) {
        kafkaTemplate.send(rewardTopic, userId.toString(),
            new RewardRedeemedEvent(UUID.randomUUID().toString(), userId.toString(),
                rewardId.toString(), pointsSpent, Instant.now()));
    }

    public record PointsEarnedEvent(String eventId, String userId, long delta, long total, String tier, Instant occurredAt) {}
    public record TierUpgradeEvent(String userId, String previousTier, String newTier, Instant occurredAt) {}
    public record RewardRedeemedEvent(String eventId, String userId, String rewardId, long pointsSpent, Instant occurredAt) {}
}
