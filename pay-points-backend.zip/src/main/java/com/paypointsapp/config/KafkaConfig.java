package com.paypointsapp.config;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

@Configuration
public class KafkaConfig {

    @Value("${app.kafka.topics.payment-events}") private String paymentTopic;
    @Value("${app.kafka.topics.point-events}")   private String pointTopic;
    @Value("${app.kafka.topics.reward-events}")  private String rewardTopic;
    @Value("${app.kafka.topics.fraud-alerts}")   private String fraudTopic;

    @Bean public NewTopic paymentEventsTopic() { return TopicBuilder.name(paymentTopic).partitions(6).replicas(1).build(); }
    @Bean public NewTopic pointEventsTopic()   { return TopicBuilder.name(pointTopic).partitions(3).replicas(1).build(); }
    @Bean public NewTopic rewardEventsTopic()  { return TopicBuilder.name(rewardTopic).partitions(3).replicas(1).build(); }
    @Bean public NewTopic fraudAlertsTopic()   { return TopicBuilder.name(fraudTopic).partitions(3).replicas(1).build(); }
}
