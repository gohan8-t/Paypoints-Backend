package com.paypointsapp.auth.dto;

import jakarta.validation.constraints.*;

public record RegisterRequest(
    @NotBlank @Email String email,
    @NotBlank @Size(min = 8, max = 100) String password,
    @NotBlank @Size(min = 2, max = 100) String fullName,
    @Pattern(regexp = "^\\+?[0-9]{10,15}$") String phone
) {}
