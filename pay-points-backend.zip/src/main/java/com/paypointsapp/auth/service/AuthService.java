package com.paypointsapp.auth.service;

import com.paypointsapp.auth.dto.*;
import com.paypointsapp.auth.entity.RefreshToken;
import com.paypointsapp.auth.entity.User;
import com.paypointsapp.auth.repository.RefreshTokenRepository;
import com.paypointsapp.auth.repository.UserRepository;
import com.paypointsapp.exception.ResourceNotFoundException;
import com.paypointsapp.rewards.service.RewardsService;
import com.paypointsapp.security.JwtService;
import com.paypointsapp.wallet.service.WalletService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final WalletService walletService;
    private final RewardsService rewardsService;

    @Transactional
    public TokenResponse register(RegisterRequest req) {
        if (userRepository.existsByEmail(req.email()))
            throw new IllegalArgumentException("Email already in use: " + req.email());

        User user = User.builder()
            .email(req.email())
            .password(passwordEncoder.encode(req.password()))
            .fullName(req.fullName())
            .phone(req.phone())
            .role(User.Role.USER)
            .build();
        userRepository.save(user);

        // Auto-provision wallet + points account
        walletService.createWallet(user.getId(), "ZAR");
        rewardsService.getOrCreateAccount(user.getId());

        log.info("Registered new user {}", user.getId());
        return issueTokens(user);
    }

    @Transactional
    public TokenResponse login(LoginRequest req) {
        User user = userRepository.findByEmail(req.email())
            .orElseThrow(() -> new BadCredentialsException("Invalid credentials"));

        if (!passwordEncoder.matches(req.password(), user.getPassword()))
            throw new BadCredentialsException("Invalid credentials");

        return issueTokens(user);
    }

    @Transactional
    public TokenResponse refresh(String refreshToken) {
        RefreshToken rt = refreshTokenRepository.findByTokenAndRevokedFalse(refreshToken)
            .orElseThrow(() -> new BadCredentialsException("Invalid refresh token"));

        if (rt.isExpired()) {
            rt.setRevoked(true);
            refreshTokenRepository.save(rt);
            throw new BadCredentialsException("Refresh token expired");
        }

        User user = userRepository.findById(rt.getUserId())
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        rt.setRevoked(true);
        refreshTokenRepository.save(rt);
        return issueTokens(user);
    }

    private TokenResponse issueTokens(User user) {
        String access  = jwtService.generateAccessToken(user.getId(), user.getEmail(), user.getRole().name());
        String refresh = jwtService.generateRefreshToken(user.getId());

        refreshTokenRepository.save(RefreshToken.builder()
            .userId(user.getId())
            .token(refresh)
            .expiresAt(Instant.now().plusMillis(jwtService.getRefreshExpirationMs()))
            .build());

        return TokenResponse.of(access, refresh, jwtService.getExpirationMs());
    }
}
