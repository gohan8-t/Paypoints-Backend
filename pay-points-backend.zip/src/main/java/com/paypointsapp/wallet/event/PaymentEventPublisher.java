package com.paypointsapp.wallet.event;

import com.paypointsapp.wallet.entity.Transaction;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class PaymentEventPublisher {

    private final KafkaTemplate<String, PaymentEvent> kafkaTemplate;

    @Value("${app.kafka.topics.payment-events}")
    private String topic;

    public void publishPaymentEvent(UUID userId, Transaction tx, BigDecimal newBalance) {
        PaymentEvent event = new PaymentEvent(
            UUID.randomUUID().toString(),
            userId.toString(),
            tx.getWalletId().toString(),
            tx.getType().name(),
            tx.getAmount(),
            tx.getReference(),
            newBalance,
            Instant.now()
        );
        kafkaTemplate.send(topic, userId.toString(), event)
            .whenComplete((result, ex) -> {
                if (ex != null) log.error("Failed to publish payment event for tx {}", tx.getId(), ex);
                else log.debug("Published payment event for tx {} to partition {}",
                    tx.getId(), result.getRecordMetadata().partition());
            });
    }
}
