package com.paypointsapp.wallet.event;

import java.math.BigDecimal;
import java.time.Instant;

public record PaymentEvent(
    String eventId,
    String userId,
    String walletId,
    String type,
    BigDecimal amount,
    String reference,
    BigDecimal balanceAfter,
    Instant occurredAt
) {}
