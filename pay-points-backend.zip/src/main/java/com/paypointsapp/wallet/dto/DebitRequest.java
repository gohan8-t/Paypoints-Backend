package com.paypointsapp.wallet.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public record DebitRequest(
    @NotNull @DecimalMin("0.01") BigDecimal amount,
    @NotBlank @Size(max = 100) String reference,
    String description
) {}
