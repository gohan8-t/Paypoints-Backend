package com.paypointsapp.wallet.dto;

import com.paypointsapp.wallet.entity.Transaction.TransactionType;
import com.paypointsapp.wallet.entity.Transaction.TransactionStatus;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record TransactionDto(
    UUID id,
    UUID walletId,
    TransactionType type,
    BigDecimal amount,
    String reference,
    TransactionStatus status,
    String description,
    Instant createdAt
) {}
