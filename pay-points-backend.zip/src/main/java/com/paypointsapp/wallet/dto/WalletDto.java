package com.paypointsapp.wallet.dto;

import com.paypointsapp.wallet.entity.Wallet.WalletStatus;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record WalletDto(
    UUID id,
    UUID userId,
    BigDecimal balance,
    String currency,
    WalletStatus status,
    Instant createdAt
) {}
