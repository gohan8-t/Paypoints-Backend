package com.paypointsapp.wallet.service;

import com.paypointsapp.exception.InsufficientFundsException;
import com.paypointsapp.exception.ResourceNotFoundException;
import com.paypointsapp.wallet.dto.*;
import com.paypointsapp.wallet.entity.Transaction;
import com.paypointsapp.wallet.entity.Transaction.TransactionStatus;
import com.paypointsapp.wallet.entity.Transaction.TransactionType;
import com.paypointsapp.wallet.entity.Wallet;
import com.paypointsapp.wallet.event.PaymentEventPublisher;
import com.paypointsapp.wallet.repository.TransactionRepository;
import com.paypointsapp.wallet.repository.WalletRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class WalletService {

    private final WalletRepository walletRepository;
    private final TransactionRepository transactionRepository;
    private final PaymentEventPublisher eventPublisher;
    private final WalletMapper walletMapper;

    @Transactional(readOnly = true)
    public WalletDto getWallet(UUID userId) {
        Wallet wallet = walletRepository.findByUserId(userId)
            .orElseThrow(() -> new ResourceNotFoundException("Wallet not found for user: " + userId));
        return walletMapper.toDto(wallet);
    }

    @Transactional
    public WalletDto createWallet(UUID userId, String currency) {
        Wallet wallet = Wallet.builder()
            .userId(userId)
            .balance(BigDecimal.ZERO)
            .currency(currency)
            .status(Wallet.WalletStatus.ACTIVE)
            .build();
        Wallet saved = walletRepository.save(wallet);
        log.info("Created wallet {} for user {}", saved.getId(), userId);
        return walletMapper.toDto(saved);
    }

    @Transactional
    public TransactionDto credit(UUID userId, CreditRequest req) {
        Wallet wallet = walletRepository.findByUserId(userId)
            .orElseThrow(() -> new ResourceNotFoundException("Wallet not found for user: " + userId));

        if (transactionRepository.existsByReference(req.reference())) {
            throw new IllegalArgumentException("Duplicate reference: " + req.reference());
        }

        // Pessimistic lock on the wallet row
        wallet = walletRepository.findByIdForUpdate(wallet.getId())
            .orElseThrow(() -> new ResourceNotFoundException("Wallet not found: " + wallet.getId()));

        wallet.credit(req.amount());
        walletRepository.save(wallet);

        Transaction tx = Transaction.builder()
            .walletId(wallet.getId())
            .type(TransactionType.CREDIT)
            .amount(req.amount())
            .reference(req.reference())
            .description(req.description())
            .status(TransactionStatus.COMPLETED)
            .build();

        Transaction saved = transactionRepository.save(tx);
        eventPublisher.publishPaymentEvent(wallet.getUserId(), tx, wallet.getBalance());
        log.debug("Credited {} to wallet {}, new balance: {}", req.amount(), wallet.getId(), wallet.getBalance());
        return walletMapper.txToDto(saved);
    }

    @Transactional
    public TransactionDto debit(UUID userId, DebitRequest req) {
        Wallet wallet = walletRepository.findByUserId(userId)
            .orElseThrow(() -> new ResourceNotFoundException("Wallet not found for user: " + userId));

        if (transactionRepository.existsByReference(req.reference())) {
            throw new IllegalArgumentException("Duplicate reference: " + req.reference());
        }

        wallet = walletRepository.findByIdForUpdate(wallet.getId())
            .orElseThrow(() -> new ResourceNotFoundException("Wallet not found: " + wallet.getId()));

        if (wallet.getBalance().compareTo(req.amount()) < 0) {
            throw new InsufficientFundsException(
                "Balance " + wallet.getBalance() + " insufficient for debit of " + req.amount());
        }

        wallet.debit(req.amount());
        walletRepository.save(wallet);

        Transaction tx = Transaction.builder()
            .walletId(wallet.getId())
            .type(TransactionType.DEBIT)
            .amount(req.amount())
            .reference(req.reference())
            .description(req.description())
            .status(TransactionStatus.COMPLETED)
            .build();

        Transaction saved = transactionRepository.save(tx);
        eventPublisher.publishPaymentEvent(wallet.getUserId(), tx, wallet.getBalance());
        return walletMapper.txToDto(saved);
    }

    @Transactional(readOnly = true)
    public Page<TransactionDto> getTransactions(UUID userId, int page, int size) {
        Wallet wallet = walletRepository.findByUserId(userId)
            .orElseThrow(() -> new ResourceNotFoundException("Wallet not found for user: " + userId));
        return transactionRepository
            .findByWalletIdOrderByCreatedAtDesc(wallet.getId(), PageRequest.of(page, size))
            .map(walletMapper::txToDto);
    }
}
