package com.paypointsapp.wallet.service;

import com.paypointsapp.wallet.dto.TransactionDto;
import com.paypointsapp.wallet.dto.WalletDto;
import com.paypointsapp.wallet.entity.Transaction;
import com.paypointsapp.wallet.entity.Wallet;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface WalletMapper {
    WalletDto toDto(Wallet wallet);
    TransactionDto txToDto(Transaction transaction);
}
