package com.paypointsapp.wallet.controller;

import com.paypointsapp.security.UserPrincipal;
import com.paypointsapp.wallet.dto.*;
import com.paypointsapp.wallet.service.WalletService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/wallet")
@RequiredArgsConstructor
public class WalletController {

    private final WalletService walletService;

    @GetMapping
    public ResponseEntity<WalletDto> getWallet(@AuthenticationPrincipal UserPrincipal user) {
        return ResponseEntity.ok(walletService.getWallet(user.id()));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public WalletDto createWallet(@AuthenticationPrincipal UserPrincipal user,
                                  @RequestParam(defaultValue = "ZAR") String currency) {
        return walletService.createWallet(user.id(), currency);
    }

    @PostMapping("/credit")
    public ResponseEntity<TransactionDto> credit(@AuthenticationPrincipal UserPrincipal user,
                                                  @Valid @RequestBody CreditRequest req) {
        return ResponseEntity.ok(walletService.credit(user.id(), req));
    }

    @PostMapping("/debit")
    public ResponseEntity<TransactionDto> debit(@AuthenticationPrincipal UserPrincipal user,
                                                 @Valid @RequestBody DebitRequest req) {
        return ResponseEntity.ok(walletService.debit(user.id(), req));
    }

    @GetMapping("/transactions")
    public ResponseEntity<Page<TransactionDto>> transactions(
            @AuthenticationPrincipal UserPrincipal user,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(walletService.getTransactions(user.id(), page, size));
    }
}
