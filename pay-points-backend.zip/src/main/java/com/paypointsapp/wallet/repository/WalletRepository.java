package com.paypointsapp.wallet.repository;

import com.paypointsapp.wallet.entity.Wallet;
import com.paypointsapp.wallet.entity.Wallet.WalletStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import jakarta.persistence.LockModeType;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface WalletRepository extends JpaRepository<Wallet, UUID> {

    Optional<Wallet> findByUserId(UUID userId);

    // Pessimistic write lock to prevent concurrent balance updates
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT w FROM Wallet w WHERE w.id = :id")
    Optional<Wallet> findByIdForUpdate(UUID id);

    boolean existsByUserIdAndStatus(UUID userId, WalletStatus status);
}
