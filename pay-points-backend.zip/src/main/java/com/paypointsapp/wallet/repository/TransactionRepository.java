package com.paypointsapp.wallet.repository;

import com.paypointsapp.wallet.entity.Transaction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, UUID> {

    Page<Transaction> findByWalletIdOrderByCreatedAtDesc(UUID walletId, Pageable pageable);

    Optional<Transaction> findByReference(String reference);

    boolean existsByReference(String reference);

    List<Transaction> findByWalletIdAndCreatedAtBetween(UUID walletId, Instant from, Instant to);
}
