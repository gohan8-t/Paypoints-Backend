package com.paypointsapp.rewards;

import com.paypointsapp.exception.InsufficientPointsException;
import com.paypointsapp.exception.ResourceNotFoundException;
import com.paypointsapp.rewards.dto.RedemptionDto;
import com.paypointsapp.rewards.entity.PointsAccount;
import com.paypointsapp.rewards.entity.Reward;
import com.paypointsapp.rewards.entity.RewardRedemption;
import com.paypointsapp.rewards.event.RewardEventPublisher;
import com.paypointsapp.rewards.repository.PointsAccountRepository;
import com.paypointsapp.rewards.repository.RedemptionRepository;
import com.paypointsapp.rewards.repository.RewardRepository;
import com.paypointsapp.rewards.service.RewardsMapper;
import com.paypointsapp.rewards.service.RewardsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RewardsServiceTest {

    @Mock PointsAccountRepository pointsAccountRepository;
    @Mock RewardRepository rewardRepository;
    @Mock RedemptionRepository redemptionRepository;
    @Mock RewardEventPublisher eventPublisher;
    @Mock RewardsMapper rewardsMapper;
    @InjectMocks RewardsService rewardsService;

    private UUID userId;
    private PointsAccount account;
    private Reward reward;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        account = PointsAccount.builder()
            .id(UUID.randomUUID()).userId(userId)
            .totalPoints(2000L).tier(PointsAccount.Tier.SILVER)
            .build();
        reward = Reward.builder()
            .id(UUID.randomUUID()).name("Coffee")
            .costPoints(500L).category("FOOD")
            .active(true).stock(-1)
            .build();
    }

    @Test
    @DisplayName("earnPoints awards points and upgrades tier")
    void earnPoints_upgradesTier() {
        account.setTotalPoints(900L);
        account.setTier(PointsAccount.Tier.BRONZE);
        when(pointsAccountRepository.findByUserIdForUpdate(userId)).thenReturn(Optional.of(account));
        when(pointsAccountRepository.save(any())).thenReturn(account);

        rewardsService.earnPoints(userId, 200L, "PAYMENT", UUID.randomUUID());

        assertThat(account.getTotalPoints()).isEqualTo(1100L);
        assertThat(account.getTier()).isEqualTo(PointsAccount.Tier.SILVER);
        verify(eventPublisher).publishTierUpgrade(userId, PointsAccount.Tier.BRONZE, PointsAccount.Tier.SILVER);
    }

    @Test
    @DisplayName("redeemReward deducts points on success")
    void redeemReward_success_deductsPoints() {
        when(rewardRepository.findById(reward.getId())).thenReturn(Optional.of(reward));
        when(pointsAccountRepository.findByUserIdForUpdate(userId)).thenReturn(Optional.of(account));
        when(redemptionRepository.save(any())).thenAnswer(i -> i.getArgument(0));

        RewardRedemption redemption = RewardRedemption.builder()
            .id(UUID.randomUUID()).userId(userId).rewardId(reward.getId())
            .pointsSpent(500L).status(RewardRedemption.RedemptionStatus.COMPLETED).build();
        when(redemptionRepository.save(any())).thenReturn(redemption);
        when(rewardsMapper.redemptionToDto(any())).thenReturn(
            new RedemptionDto(redemption.getId(), reward.getId(), 500L, RewardRedemption.RedemptionStatus.COMPLETED, null));

        RedemptionDto result = rewardsService.redeemReward(userId, reward.getId());

        assertThat(result.pointsSpent()).isEqualTo(500L);
        assertThat(account.getTotalPoints()).isEqualTo(1500L);
    }

    @Test
    @DisplayName("redeemReward throws when points insufficient")
    void redeemReward_insufficientPoints_throws() {
        reward.setCostPoints(5000L);
        when(rewardRepository.findById(reward.getId())).thenReturn(Optional.of(reward));
        when(pointsAccountRepository.findByUserIdForUpdate(userId)).thenReturn(Optional.of(account));

        assertThatThrownBy(() -> rewardsService.redeemReward(userId, reward.getId()))
            .isInstanceOf(InsufficientPointsException.class);
    }
}
