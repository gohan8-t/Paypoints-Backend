package com.paypointsapp.wallet;

import com.paypointsapp.exception.InsufficientFundsException;
import com.paypointsapp.exception.ResourceNotFoundException;
import com.paypointsapp.wallet.dto.CreditRequest;
import com.paypointsapp.wallet.dto.DebitRequest;
import com.paypointsapp.wallet.dto.TransactionDto;
import com.paypointsapp.wallet.dto.WalletDto;
import com.paypointsapp.wallet.entity.Transaction;
import com.paypointsapp.wallet.entity.Wallet;
import com.paypointsapp.wallet.event.PaymentEventPublisher;
import com.paypointsapp.wallet.repository.TransactionRepository;
import com.paypointsapp.wallet.repository.WalletRepository;
import com.paypointsapp.wallet.service.WalletMapper;
import com.paypointsapp.wallet.service.WalletService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class WalletServiceTest {

    @Mock WalletRepository walletRepository;
    @Mock TransactionRepository transactionRepository;
    @Mock PaymentEventPublisher eventPublisher;
    @Mock WalletMapper walletMapper;
    @InjectMocks WalletService walletService;

    private UUID userId;
    private Wallet wallet;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        wallet = Wallet.builder()
            .id(UUID.randomUUID())
            .userId(userId)
            .balance(new BigDecimal("100.00"))
            .currency("ZAR")
            .status(Wallet.WalletStatus.ACTIVE)
            .build();
    }

    @Test
    @DisplayName("getWallet returns DTO for existing user")
    void getWallet_existingUser_returnsDto() {
        when(walletRepository.findByUserId(userId)).thenReturn(Optional.of(wallet));
        WalletDto dto = new WalletDto(wallet.getId(), userId, wallet.getBalance(), "ZAR", Wallet.WalletStatus.ACTIVE, null);
        when(walletMapper.toDto(wallet)).thenReturn(dto);

        WalletDto result = walletService.getWallet(userId);

        assertThat(result).isNotNull();
        assertThat(result.balance()).isEqualTo(new BigDecimal("100.00"));
    }

    @Test
    @DisplayName("getWallet throws when wallet not found")
    void getWallet_notFound_throws() {
        when(walletRepository.findByUserId(userId)).thenReturn(Optional.empty());
        assertThatThrownBy(() -> walletService.getWallet(userId))
            .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("credit increases balance and publishes event")
    void credit_validAmount_increasesBalance() {
        when(walletRepository.findByUserId(userId)).thenReturn(Optional.of(wallet));
        when(walletRepository.findByIdForUpdate(wallet.getId())).thenReturn(Optional.of(wallet));
        when(transactionRepository.existsByReference(anyString())).thenReturn(false);

        Transaction tx = Transaction.builder()
            .id(UUID.randomUUID()).walletId(wallet.getId())
            .type(Transaction.TransactionType.CREDIT)
            .amount(new BigDecimal("50.00")).reference("REF-001")
            .status(Transaction.TransactionStatus.COMPLETED).build();
        when(transactionRepository.save(any())).thenReturn(tx);
        TransactionDto txDto = new TransactionDto(tx.getId(), wallet.getId(), tx.getType(), tx.getAmount(), tx.getReference(), tx.getStatus(), null, null);
        when(walletMapper.txToDto(tx)).thenReturn(txDto);

        CreditRequest req = new CreditRequest(new BigDecimal("50.00"), "REF-001", null);
        TransactionDto result = walletService.credit(userId, req);

        assertThat(result.amount()).isEqualTo(new BigDecimal("50.00"));
        assertThat(wallet.getBalance()).isEqualTo(new BigDecimal("150.00"));
        verify(eventPublisher).publishPaymentEvent(eq(userId), eq(tx), eq(wallet.getBalance()));
    }

    @Test
    @DisplayName("debit throws InsufficientFundsException when balance too low")
    void debit_insufficientBalance_throws() {
        when(walletRepository.findByUserId(userId)).thenReturn(Optional.of(wallet));
        when(walletRepository.findByIdForUpdate(wallet.getId())).thenReturn(Optional.of(wallet));
        when(transactionRepository.existsByReference(anyString())).thenReturn(false);

        DebitRequest req = new DebitRequest(new BigDecimal("200.00"), "REF-002", null);
        assertThatThrownBy(() -> walletService.debit(userId, req))
            .isInstanceOf(InsufficientFundsException.class)
            .hasMessageContaining("insufficient");
    }

    @Test
    @DisplayName("debit rejects duplicate reference")
    void debit_duplicateReference_throws() {
        when(walletRepository.findByUserId(userId)).thenReturn(Optional.of(wallet));
        when(transactionRepository.existsByReference("DUP-001")).thenReturn(true);

        DebitRequest req = new DebitRequest(new BigDecimal("10.00"), "DUP-001", null);
        assertThatThrownBy(() -> walletService.debit(userId, req))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageContaining("Duplicate");
    }
}
